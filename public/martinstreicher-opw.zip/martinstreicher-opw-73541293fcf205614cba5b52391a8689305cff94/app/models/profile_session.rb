class ProfileSession < Authlogic::Session::Base
end