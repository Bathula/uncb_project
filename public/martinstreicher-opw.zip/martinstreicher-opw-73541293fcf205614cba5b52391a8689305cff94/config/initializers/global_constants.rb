CONTACT_RECIPIENTS            = %w( info@originalprojects.com )
ERROR_RECIPIENTS              = %w( info@originalprojects.com )
INFO_AT_OP_EMAIL              = %w( info@originalprojects.com )
INVITATION_REQUEST_RECIPIENTS = %w( invitations@originalprojects.com )
SESSION_PROFILE_ID            = 'profile_id'
SITE                          = ( RAILS_ENV == 'production' ) ? 'originalprojects.com' : 'localhost:3000'
SITE_NAME                     = 'Original Projects'
SUPPORT_EMAIL                 = "Original Projects <info@originalprojects.com>"
INVITE_EMAIL                  = "Original Projects <invite@originalprojects.com>"
