HoptoadNotifier.configure do |config|
  config.api_key = '70869b5535544889656b072b23e59538'
end
