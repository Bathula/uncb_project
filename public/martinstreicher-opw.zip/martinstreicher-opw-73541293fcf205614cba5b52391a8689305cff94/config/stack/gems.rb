package :rmagick do
  gem 'rmagick'
  requires :imagemagick
end

package :s3 do
  gem 's3sync'
  gem 'aws-s3'
end
