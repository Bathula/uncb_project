package :imagemagick do
  apt %w(imagemagick libmagickwand-dev libtiff-tools)
end
