package :rsync do
  description 'rsync'
  apt 'rsync'
end
