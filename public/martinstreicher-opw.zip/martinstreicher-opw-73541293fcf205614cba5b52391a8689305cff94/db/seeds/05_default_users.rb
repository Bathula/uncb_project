Profile.create!(:username => 'cnixon', 
                :email => 'clinton.nixon@viget.com',
                :display_name => "Clinton R. Nixon",
                :password => 'password',
                :password_confirmation => 'password',
                :city => 'Durham',
                :tos_accepted => '1')